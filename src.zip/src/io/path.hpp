#ifndef EDEN_IO_PATH_HPP
#define EDEN_IO_PATH_HPP

#include "core/object/managed_object.hpp"

#include <filesystem>
#include <string>
#include <vector>

namespace Eden::IO
{
    namespace fs = std::filesystem;

    namespace Managed
    {
        class PathData : public virtual OBJECT
        {
        public:
            fs::path m_Path;
        };
    }

    class Path : public MANAGEDOBJECT<Managed::PathData>
    {
    public:
        using NativePath = fs::path;

    public:
        // =====================================================
        // Konstruktorok
        // =====================================================

        Path(const char* path);
        Path(const std::string& path);
        Path(const std::wstring& path);
        Path(const fs::path& path);

        // =====================================================
        // Alap elérés
        // =====================================================

        const fs::path& Native() const;
        fs::path& Native();

        std::string ToString() const;
        std::wstring ToWString() const;

        operator fs::path() const;

        bool Empty() const;
        void Clear();

        // =====================================================
        // Nem statikus C#-szerű metódusok
        // =====================================================

        std::string FileName() const;
        std::string FileNameWithoutExtension() const;
        std::string Extension() const;

        Path DirectoryName() const;
        Path Root() const;

        bool HasExtension() const;
        bool IsRooted() const;
        bool IsFullyQualified() const;

        Path FullPath() const;
        Path Normalized() const;
        Path RelativeTo(const Path& basePath) const;

        Path WithExtension(const Path& extension) const;
        Path WithFileName(const Path& fileName) const;
        Path CombineWith(const Path& other) const;

        void Append(const Path& part);
        void ReplaceExtension(const Path& extension);
        void ReplaceFileName(const Path& fileName);
        void MakePreferred();

        // =====================================================
        // Operátorok
        // =====================================================

        Path operator/(const Path& other) const;
        Path& operator/=(const Path& other);

        bool operator==(const Path& other) const;
        bool operator!=(const Path& other) const;

        // =====================================================
        // String formátumok
        // =====================================================

        std::string String() const;
        std::string GenericString() const;
        std::string PreferredString() const;

        // =====================================================
        // Has... metódusok
        // =====================================================

        bool HasRootName() const;
        bool HasRootDirectory() const;
        bool HasRootPath() const;
        bool HasRelativePath() const;
        bool HasParentPath() const;
        bool HasFileName() const;
        bool HasStem() const;

        // =====================================================
        // Nem statikus C++ std::filesystem-szerű aliasok
        // =====================================================

        Path filename() const;
        Path stem() const;
        Path extension() const;
        Path parent_path() const;
        Path root_path() const;
        Path root_name() const;
        Path root_directory() const;
        Path relative_path() const;

        Path lexically_normal() const;
        Path lexically_relative(const Path& base) const;

        bool is_absolute() const;
        bool is_relative() const;

        // =====================================================
        // Statikus C# Path-szerű metódusok
        // =====================================================

        template <typename... TParts>
        static Path Combine(const TParts&... parts)
        {
            fs::path result;
            ((result /= ToNativePath(parts)), ...);
            return Path(result);
        }

        template <typename... TParts>
        static Path Join(const TParts&... parts)
        {
            fs::path result;
            ((result /= ToNativePath(parts)), ...);
            return Path(result);
        }

        static std::string GetFileName(const Path& path);
        static std::string GetFileNameWithoutExtension(const Path& path);
        static std::string GetExtension(const Path& path);

        static Path GetDirectoryName(const Path& path);
        static Path GetPathRoot(const Path& path);

        static bool HasExtension(const Path& path);
        static bool IsPathRooted(const Path& path);
        static bool IsPathFullyQualified(const Path& path);

        static Path ChangeExtension(const Path& path, const Path& extension);

        static Path GetFullPath(const Path& path);
        static Path GetRelativePath(const Path& relativeTo, const Path& path);

        static Path GetTempPath();

        // =====================================================
        // Statikus C++ std::filesystem-szerű metódusok
        // =====================================================

        static Path Absolute(const Path& path);
        static Path WeaklyCanonical(const Path& path);
        static Path Canonical(const Path& path);

        static Path LexicallyNormal(const Path& path);
        static Path LexicallyRelative(const Path& path, const Path& base);

        static fs::path::value_type DirectorySeparatorChar();

        static bool EndsInDirectorySeparator(const Path& path);
        static Path TrimEndingDirectorySeparator(const Path& path);

        static std::vector<char> GetInvalidFileNameChars();
        static std::vector<char> GetInvalidPathChars();

    private:
        template <typename T>
        static fs::path ToNativePath(const T& value)
        {
            return fs::path(value);
        }

        static fs::path ToNativePath(const Path& value)
        {
            return value.Native();
        }
    };
}

#endif // EDEN_IO_PATH_HPP