#ifndef EDEN_IO_DIRECTORY_HPP
#define EDEN_IO_DIRECTORY_HPP

#include "core/object/managed_object.hpp"

#include <filesystem>
#include <vector>
#include <string>

namespace Eden::IO
{
    namespace fs = std::filesystem;
    namespace Managed
    {
        class DirectoryData : public virtual OBJECT
        {
        public:
            fs::path m_path;
        };
    }

    class Directory : public MANAGEDOBJECT<Managed::DirectoryData>
    {
    public:
        Directory(const fs::path &path);

        const fs::path &Path() const
        {
            return data()->m_path;
        }

        std::string Name() const
        {
            return data()->m_path.filename().string();
        }

        fs::path Parent() const
        {
            return data()->m_path.parent_path();
        }

        bool Exists() const
        {
            return Directory::Exists(data()->m_path);
        }

        void Create() const
        {
            Directory::Create(data()->m_path);
        }

        void Delete(bool recursive = false) const
        {
            Directory::Delete(data()->m_path, recursive);
        }

        void MoveTo(const fs::path &target) const
        {
            Directory::Move(data()->m_path, target);
        }

        void CopyTo(const fs::path &target, bool overwrite = false) const
        {
            Directory::Copy(data()->m_path, target, overwrite);
        }

        std::vector<fs::path> GetFiles(bool recursive = false) const
        {
            return Directory::GetFiles(data()->m_path, recursive);
        }

        std::vector<fs::path> GetDirectories(bool recursive = false) const
        {
            return Directory::GetDirectories(data()->m_path, recursive);
        }

        std::vector<fs::path> GetEntries(bool recursive = false) const
        {
            return Directory::GetEntries(data()->m_path, recursive);
        }
/**=======================================================================================================================*
 **                                                  REGION STATIC
 *========================================================================================================================*/
#pragma region STATIC

        static bool Exists(const fs::path &path)
        {
            return fs::exists(path) && fs::is_directory(path);
        }

        static void Create(const fs::path &path)
        {
            fs::create_directories(path);
        }

        static void Delete(const fs::path &path, bool recursive = false)
        {
            if (!Exists(path))
                return;

            if (recursive)
            {
                fs::remove_all(path);
            }
            else
            {
                fs::remove(path);
            }
        }

        static void Move(const fs::path &source, const fs::path &target)
        {
            fs::rename(source, target);
        }

        static void Copy(const fs::path &source, const fs::path &target, bool overwrite = false)
        {
            fs::copy_options options = fs::copy_options::recursive;

            if (overwrite)
            {
                options |= fs::copy_options::overwrite_existing;
            }
            else
            {
                options |= fs::copy_options::skip_existing;
            }

            fs::copy(source, target, options);
        }

        static std::vector<fs::path> GetFiles(const fs::path &path, bool recursive = false)
        {
            std::vector<fs::path> result;

            if (!Exists(path))
                return result;

            if (recursive)
            {
                for (const auto &entry : fs::recursive_directory_iterator(path))
                {
                    if (entry.is_regular_file())
                        result.push_back(entry.path());
                }
            }
            else
            {
                for (const auto &entry : fs::directory_iterator(path))
                {
                    if (entry.is_regular_file())
                        result.push_back(entry.path());
                }
            }

            return result;
        }

        static std::vector<fs::path> GetDirectories(const fs::path &path, bool recursive = false)
        {
            std::vector<fs::path> result;

            if (!Exists(path))
                return result;

            if (recursive)
            {
                for (const auto &entry : fs::recursive_directory_iterator(path))
                {
                    if (entry.is_directory())
                        result.push_back(entry.path());
                }
            }
            else
            {
                for (const auto &entry : fs::directory_iterator(path))
                {
                    if (entry.is_directory())
                        result.push_back(entry.path());
                }
            }

            return result;
        }

        static std::vector<fs::path> GetEntries(const fs::path &path, bool recursive = false)
        {
            std::vector<fs::path> result;

            if (!Exists(path))
                return result;

            if (recursive)
            {
                for (const auto &entry : fs::recursive_directory_iterator(path))
                {
                    result.push_back(entry.path());
                }
            }
            else
            {
                for (const auto &entry : fs::directory_iterator(path))
                {
                    result.push_back(entry.path());
                }
            }

            return result;
        }

        static fs::path GetCurrentDirectory()
        {
            return fs::current_path();
        }

        static void SetCurrentDirectory(const fs::path &path)
        {
            fs::current_path(path);
        }

/**=======================================================================================================================*
 **                                           END OF REGION STATIC
 *========================================================================================================================*/
#pragma endregion STATIC
    };
}

#endif // EDEN_IO_DIRECTORY_HPP