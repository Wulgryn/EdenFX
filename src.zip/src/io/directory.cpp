#include "directory.hpp"
using namespace Eden::IO;

Directory::Directory(const fs::path &path)
{
    data()->m_path = path;
}
