#include "path.hpp"
using namespace Eden::IO;

// =====================================================
// Konstruktorok
// =====================================================

Path::Path(const char *path)
{
    if (path != nullptr)
    {
        this->data()->m_Path = fs::path(path);
    }
}

Path::Path(const std::string &path)
{
    this->data()->m_Path = fs::path(path);
}

Path::Path(const std::wstring &path)
{
    this->data()->m_Path = fs::path(path);
}

Path::Path(const fs::path &path)
{
    this->data()->m_Path = path;
}

// =====================================================
// Alap elérés
// =====================================================

const fs::path &Path::Native() const
{
    return this->data()->m_Path;
}

fs::path &Path::Native()
{
    return this->data()->m_Path;
}

std::string Path::ToString() const
{
    return this->data()->m_Path.string();
}

std::wstring Path::ToWString() const
{
    return this->data()->m_Path.wstring();
}

Path::operator fs::path() const
{
    return this->data()->m_Path;
}

bool Path::Empty() const
{
    return this->data()->m_Path.empty();
}

void Path::Clear()
{
    this->data()->m_Path.clear();
}

// =====================================================
// Nem statikus C#-szerű metódusok
// =====================================================

std::string Path::FileName() const
{
    return this->data()->m_Path.filename().string();
}

std::string Path::FileNameWithoutExtension() const
{
    return this->data()->m_Path.stem().string();
}

std::string Path::Extension() const
{
    return this->data()->m_Path.extension().string();
}

Path Path::DirectoryName() const
{
    return Path(this->data()->m_Path.parent_path());
}

Path Path::Root() const
{
    return Path(this->data()->m_Path.root_path());
}

bool Path::HasExtension() const
{
    return this->data()->m_Path.has_extension();
}

bool Path::IsRooted() const
{
    return this->data()->m_Path.has_root_path();
}

bool Path::IsFullyQualified() const
{
    return this->data()->m_Path.is_absolute();
}

Path Path::FullPath() const
{
    return Path(fs::absolute(this->data()->m_Path).lexically_normal());
}

Path Path::Normalized() const
{
    return Path(this->data()->m_Path.lexically_normal());
}

Path Path::RelativeTo(const Path &basePath) const
{
    fs::path absoluteBase = fs::absolute(basePath.Native()).lexically_normal();
    fs::path absoluteThis = fs::absolute(this->data()->m_Path).lexically_normal();

    return Path(absoluteThis.lexically_relative(absoluteBase));
}

Path Path::WithExtension(const Path &extension) const
{
    fs::path result = this->data()->m_Path;
    result.replace_extension(extension.Native());
    return Path(result);
}

Path Path::WithFileName(const Path &fileName) const
{
    fs::path result = this->data()->m_Path;
    result.replace_filename(fileName.Native());
    return Path(result);
}

Path Path::CombineWith(const Path &other) const
{
    return Path(this->data()->m_Path / other.Native());
}

void Path::Append(const Path &part)
{
    this->data()->m_Path /= part.Native();
}

void Path::ReplaceExtension(const Path &extension)
{
    this->data()->m_Path.replace_extension(extension.Native());
}

void Path::ReplaceFileName(const Path &fileName)
{
    this->data()->m_Path.replace_filename(fileName.Native());
}

void Path::MakePreferred()
{
    this->data()->m_Path.make_preferred();
}

// =====================================================
// Operátorok
// =====================================================

Path Path::operator/(const Path &other) const
{
    return Path(this->data()->m_Path / other.Native());
}

Path &Path::operator/=(const Path &other)
{
    this->data()->m_Path /= other.Native();
    return *this;
}

bool Path::operator==(const Path &other) const
{
    return this->data()->m_Path == other.Native();
}

bool Path::operator!=(const Path &other) const
{
    return !(*this == other);
}

// =====================================================
// String formátumok
// =====================================================

std::string Path::String() const
{
    return this->data()->m_Path.string();
}

std::string Path::GenericString() const
{
    return this->data()->m_Path.generic_string();
}

std::string Path::PreferredString() const
{
    fs::path copy = this->data()->m_Path;
    copy.make_preferred();
    return copy.string();
}

// =====================================================
// Has... metódusok
// =====================================================

bool Path::HasRootName() const
{
    return this->data()->m_Path.has_root_name();
}

bool Path::HasRootDirectory() const
{
    return this->data()->m_Path.has_root_directory();
}

bool Path::HasRootPath() const
{
    return this->data()->m_Path.has_root_path();
}

bool Path::HasRelativePath() const
{
    return this->data()->m_Path.has_relative_path();
}

bool Path::HasParentPath() const
{
    return this->data()->m_Path.has_parent_path();
}

bool Path::HasFileName() const
{
    return this->data()->m_Path.has_filename();
}

bool Path::HasStem() const
{
    return this->data()->m_Path.has_stem();
}

// =====================================================
// Nem statikus C++ std::filesystem-szerű aliasok
// =====================================================

Path Path::filename() const
{
    return Path(this->data()->m_Path.filename());
}

Path Path::stem() const
{
    return Path(this->data()->m_Path.stem());
}

Path Path::extension() const
{
    return Path(this->data()->m_Path.extension());
}

Path Path::parent_path() const
{
    return Path(this->data()->m_Path.parent_path());
}

Path Path::root_path() const
{
    return Path(this->data()->m_Path.root_path());
}

Path Path::root_name() const
{
    return Path(this->data()->m_Path.root_name());
}

Path Path::root_directory() const
{
    return Path(this->data()->m_Path.root_directory());
}

Path Path::relative_path() const
{
    return Path(this->data()->m_Path.relative_path());
}

Path Path::lexically_normal() const
{
    return Path(this->data()->m_Path.lexically_normal());
}

Path Path::lexically_relative(const Path &base) const
{
    return Path(this->data()->m_Path.lexically_relative(base.Native()));
}

bool Path::is_absolute() const
{
    return this->data()->m_Path.is_absolute();
}

bool Path::is_relative() const
{
    return this->data()->m_Path.is_relative();
}

// =====================================================
// Statikus C# Path-szerű metódusok
// =====================================================

std::string Path::GetFileName(const Path &path)
{
    return path.Native().filename().string();
}

std::string Path::GetFileNameWithoutExtension(const Path &path)
{
    return path.Native().stem().string();
}

std::string Path::GetExtension(const Path &path)
{
    return path.Native().extension().string();
}

Path Path::GetDirectoryName(const Path &path)
{
    return Path(path.Native().parent_path());
}

Path Path::GetPathRoot(const Path &path)
{
    return Path(path.Native().root_path());
}

bool Path::HasExtension(const Path &path)
{
    return path.Native().has_extension();
}

bool Path::IsPathRooted(const Path &path)
{
    return path.Native().has_root_path();
}

bool Path::IsPathFullyQualified(const Path &path)
{
    return path.Native().is_absolute();
}

Path Path::ChangeExtension(const Path &path, const Path &extension)
{
    fs::path result = path.Native();
    result.replace_extension(extension.Native());
    return Path(result);
}

Path Path::GetFullPath(const Path &path)
{
    return Path(fs::absolute(path.Native()).lexically_normal());
}

Path Path::GetRelativePath(const Path &relativeTo, const Path &path)
{
    fs::path absoluteBase = fs::absolute(relativeTo.Native()).lexically_normal();
    fs::path absolutePath = fs::absolute(path.Native()).lexically_normal();

    return Path(absolutePath.lexically_relative(absoluteBase));
}

Path Path::GetTempPath()
{
    return Path(fs::temp_directory_path());
}

// =====================================================
// Statikus C++ std::filesystem-szerű metódusok
// =====================================================

Path Path::Absolute(const Path &path)
{
    return Path(fs::absolute(path.Native()));
}

Path Path::WeaklyCanonical(const Path &path)
{
    return Path(fs::weakly_canonical(path.Native()));
}

Path Path::Canonical(const Path &path)
{
    return Path(fs::canonical(path.Native()));
}

Path Path::LexicallyNormal(const Path &path)
{
    return Path(path.Native().lexically_normal());
}

Path Path::LexicallyRelative(const Path &path, const Path &base)
{
    return Path(path.Native().lexically_relative(base.Native()));
}

fs::path::value_type Path::DirectorySeparatorChar()
{
    return fs::path::preferred_separator;
}

bool Path::EndsInDirectorySeparator(const Path &path)
{
    auto text = path.Native().native();

    if (text.empty())
    {
        return false;
    }

    auto last = text[text.size() - 1];

    return last == static_cast<fs::path::value_type>('/') ||
           last == static_cast<fs::path::value_type>('\\');
}

Path Path::TrimEndingDirectorySeparator(const Path &path)
{
    auto text = path.Native().native();

    if (text.empty())
    {
        return Path();
    }

    std::size_t minSize = path.Native().root_path().native().size();

    if (minSize == 0)
    {
        minSize = 1;
    }

    while (text.size() > minSize)
    {
        auto last = text[text.size() - 1];

        if (last != static_cast<fs::path::value_type>('/') &&
            last != static_cast<fs::path::value_type>('\\'))
        {
            break;
        }

        text.pop_back();
    }

    return Path(fs::path(text));
}

std::vector<char> Path::GetInvalidFileNameChars()
{
    std::vector<char> result;

#ifdef _WIN32
    const char *chars = "<>:\"/\\|?*";

    for (const char *c = chars; *c != '\0'; ++c)
    {
        result.push_back(*c);
    }

    for (int i = 0; i < 32; i++)
    {
        result.push_back(static_cast<char>(i));
    }
#else
    result.push_back('/');
    result.push_back('\0');
#endif

    return result;
}

std::vector<char> Path::GetInvalidPathChars()
{
    std::vector<char> result;

#ifdef _WIN32
    const char *chars = "<>\"|?*";

    for (const char *c = chars; *c != '\0'; ++c)
    {
        result.push_back(*c);
    }

    for (int i = 0; i < 32; i++)
    {
        result.push_back(static_cast<char>(i));
    }
#else
    result.push_back('\0');
#endif

    return result;
}