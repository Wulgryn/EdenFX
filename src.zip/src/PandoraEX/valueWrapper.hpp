#ifndef PANDORAEX_VALUE_WRAPPER_HPP
#define PANDORAEX_VALUE_WRAPPER_HPP

#include <memory>
#include <type_traits>
#include "exception.hpp"

namespace PandoraEX
{
    template <class T>
    class ValueWrapper
    {
        using Type = std::remove_const_t<std::remove_reference_t<T>>;
        Type *value = nullptr;
        const Type &refVal = *value;

    public:
        ValueWrapper() = default;
        ValueWrapper(const T &value) : refVal(value)
        {
            this->value = std::make_unique<Type>(value).get();
            if (!this->value)
            {
                ThrowExceptionF(PandoraEX::Exceptions::NullReferenceException, "Value is null.");
            }
        }

        ValueWrapper(const ValueWrapper &other) : value(other.value), refVal(other.refVal) {}
        ValueWrapper(ValueWrapper &&other) noexcept : value(other.value), refVal(other.refVal)
        {
            other.value = nullptr;
        }

        ValueWrapper &operator=(const ValueWrapper &other)
        {
            if (this != &other)
            {
                value = other.value;
                refVal = other.refVal;
            }
            return *this;
        }

        ValueWrapper &operator=(ValueWrapper &&other) noexcept
        {
            if (this != &other)
            {
                value = other.value;
                refVal = other.refVal;
                other.value = nullptr;
            }
            return *this;
        }

        template <typename ReturnType = Type>
        ReturnType get() const
        {
            if (!value)
            {
                ThrowExceptionF(PandoraEX::Exceptions::NullReferenceException, "Value is null.");
            }
            return static_cast<ReturnType>(refVal);
        }

        bool operator==(const ValueWrapper &other) const
        {
            return *value == *other.value || &refVal == &other.refVal;
        }

        bool operator==(const Type &other) const
        {
            return &refVal == &other;
        }

        bool operator!=(const ValueWrapper &other) const
        {
            return !(*this == other);
        }

        bool operator!=(const Type &other) const
        {
            return !(*this == other);
        }

        bool isPointer() const
        {
            return std::is_pointer_v<T>;
        }

        ~ValueWrapper() noexcept
        {
            if (value) delete value;
        }
    };

    template <class T>
    class ValueWrapper<T *>
    {
        using Type = std::remove_const_t<std::remove_reference_t<T>>;
        Type value = nullptr;
        public:
        ValueWrapper() = default;
        ValueWrapper(T* value) : value(value) {}

        ValueWrapper(const ValueWrapper &other) : value(other.value) {}
        ValueWrapper(ValueWrapper &&other) noexcept : value(other.value)
        {
            other.value = nullptr;
        }

        ValueWrapper &operator=(const ValueWrapper &other)
        {
            if (this != &other)
            {
                value = other.value;
            }
            return *this;
        }

        ValueWrapper &operator=(ValueWrapper &&other) noexcept
        {
            if (this != &other)
            {
                value = other.value;
                other.value = nullptr;
            }
            return *this;
        }

        template <typename OverrideType = Type>
        OverrideType get() const
        {
            return static_cast<OverrideType>(value);
        }

        bool isPointer() const
        {
            return true; // Always true for pointer types
        }

        bool operator==(const ValueWrapper<T *> &other) const
        {
            return value == other.value;
        }

        bool operator==(const T *other) const
        {
            return value == other;
        }

        bool operator!=(const ValueWrapper<T *> &other) const
        {
            return !(*this == other);
        }

        bool operator!=(const T *other) const
        {
            return !(*this == other);
        }




        ~ValueWrapper() noexcept
        {
            if (value) delete value;
        }
    };
}

#endif // PANDORAEX_VALUE_WRAPPER_HPP