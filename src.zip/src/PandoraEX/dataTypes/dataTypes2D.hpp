#ifndef DATATYPES2D_HPP
#define DATATYPES2D_HPP

// #include "vector2.hpp"
// #include "rVector2.hpp"
#include "../size2.hpp"
// #include "../rSize2.hpp"
// #include "point2.hpp"
// #include "rPoint2.hpp"

#endif // DATATYPES2D_HPP