#ifndef PANDORAUI_UIELEMENT_HPP
#define PANDORAUI_UIELEMENT_HPP

namespace PandoraUI
{
    class UIElement
    {
    public:
        UIElement() = default;
    };
}

#endif // PANDORAUI_UIELEMENT_HPP