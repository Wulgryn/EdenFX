#include "../window.hpp"

using namespace PandoraUI;

void Window::renderGUI()
{
    guiLayer.validateRemovals();
}