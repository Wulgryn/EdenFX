#include "consoleColor.hpp"

using namespace PandoraDebug;

HANDLE ConsoleColor::ms_consoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);