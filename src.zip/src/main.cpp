#include "Collections/List.hpp"
using namespace Eden::Collections;

int main([[maybe_unused]] int argc, [[maybe_unused]] char const *argv[])
{
    List<int> myList;
    myList.Add(10);
    return 0;
}