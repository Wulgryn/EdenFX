#include "PandoraUI/init.hpp"
#include "PandoraUI/window.hpp"
// #include "PandoraEX/list.hpp"
// #include "PandoraDebug/console.hpp"

// #include <windows.h>
// #include <iostream>
// using namespace std;


using namespace PandoraEX;

int main([[maybe_unused]] int argc,[[maybe_unused]] char const *argv[])
{
    PandoraUI::initialize();
    PandoraUI::Window w;
    w.initialize();
    w.open();
    
    // system("pause");
    return PandoraUI::waitForExit(true);
}
