#ifndef EDEN_COLLECTIONS_LIST_HPP
#define EDEN_COLLECTIONS_LIST_HPP

#include "core/object/managed_object.hpp"
#include <vector>
#include <algorithm>

namespace Eden::Collections
{
    namespace Managed
    {
        template <class T>
        class ListData
        {
        public:
            std::vector<T> m_VecData;
        };
    }

    template <class T>
    class List : public MANAGEDOBJECT<Managed::ListData<T>>
    {
    public:
        List(int size = 0)
        {
            this->data()->m_VecData.resize(size);
        }

        void add(const T& item)
        {
            this->data()->m_VecData.push_back(item);
        }

        T& operator[](int index)
        {
            return this->data()->m_VecData[index];
        }

        const T& operator[](int index) const
        {
            return this->data()->m_VecData[index];
        }

        int size() const
        {
            return static_cast<int>(this->data()->m_VecData.size());
        }

        void clear()
        {
            this->data()->m_VecData.clear();
        }

        int indexOf(const T& item) const
        {
            auto it = std::find(this->data()->m_VecData.begin(), this->data()->m_VecData.end(), item);
            if (it != this->data()->m_VecData.end())
            {
                return static_cast<int>(std::distance(this->data()->m_VecData.begin(), it));
            }
            return -1; // Not found
        }

        bool contains(const T& item) const
        {
            return std::find(this->data()->m_VecData.begin(), this->data()->m_VecData.end(), item) != this->data()->m_VecData.end();
        }

        void removeAt(int index)
        {
            if (index >= 0 && index < size())
            {
                this->data()->m_VecData.erase(this->data()->m_VecData.begin() + index);
            }
        }

        void remove(const T& item)
        {
            auto it = std::find(this->data()->m_VecData.begin(), this->data()->m_VecData.end(), item);
            if (it != this->data()->m_VecData.end())
            {
                this->data()->m_VecData.erase(it);
            }
        }

    };
}


#endif // EDEN_COLLECTIONS_LIST_HPP